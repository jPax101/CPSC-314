/**
 * UBC CPSC 314 (2015W1)
 * Assignment 2
 */


// ASSIGNMENT-SPECIFIC API EXTENSION
THREE.Object3D.prototype.setMatrix = function(a) {
  this.matrix=a;
  this.matrix.decompose(this.position,this.quaternion,this.scale);
}


// SETUP RENDERER AND SCENE
var scene = new THREE.Scene();
var renderer = new THREE.WebGLRenderer();
renderer.setClearColor(0xffffff); // white background colour
document.body.appendChild(renderer.domElement);


// SETUP CAMERA
var camera = new THREE.PerspectiveCamera(30, 1, 0.1, 1000); // view angle, aspect ratio, near, far
camera.position.set(50,20,35);
camera.lookAt(scene.position);
scene.add(camera);


// SETUP ORBIT CONTROL OF THE CAMERA
var controls = new THREE.OrbitControls(camera);
controls.damping = 0.2;


// ADAPT TO WINDOW RESIZE
function resize() {
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
}

window.addEventListener('resize', resize);
resize();


// FLOOR WITH CHECKERBOARD 
var floorTexture = new THREE.ImageUtils.loadTexture('images/checkerboard.jpg');
floorTexture.wrapS = floorTexture.wrapT = THREE.RepeatWrapping;
floorTexture.repeat.set(4, 4);

var floorMaterial = new THREE.MeshBasicMaterial({ map: floorTexture, side: THREE.DoubleSide });
var floorGeometry = new THREE.PlaneBufferGeometry(30, 30);
var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.position.y = -1;
floor.rotation.x = Math.PI / 2;
scene.add(floor);


// MATERIALS
var normalMaterial = new THREE.MeshNormalMaterial();


// GEOMETRY
var torsoGeometry = new THREE.SphereGeometry(2.5, 64, 64); // centered on origin
for (var i = 0; i < torsoGeometry.vertices.length; i++)
{
  torsoGeometry.vertices[i].z *= 1.4;
}
var neckGeometry = new THREE.CylinderGeometry(.4, .4, 4.5, 32);
var headGeometry = new THREE.SphereGeometry(0.7, 32, 32);
for (var i = 0; i < headGeometry.vertices.length; i++)
{
  headGeometry.vertices[i].z *= 1.5;
}
var thighGeometry = new THREE.CylinderGeometry(.8, .3, 3, 32);
for (var i = 0; i < thighGeometry.vertices.length; i++)
{
  thighGeometry.vertices[i].y -= 1.5;
}
var lowerlegGeometry = new THREE.CylinderGeometry(.3, .25, 4, 32);
for (var i = 0; i < lowerlegGeometry.vertices.length; i++)
{
  lowerlegGeometry.vertices[i].y -= 2;
}


// MATRICES
var torsoMatrix = new THREE.Matrix4().set(1,0,0,0, 0,1,0,7, 0,0,1,0, 0,0,0,1);
var neckMatrix = new THREE.Matrix4().set(1,0,0,0, 0,1,0,3.5, 0,0,1,2.5, 0,0,0,1);
var necktorsoMatrix = new THREE.Matrix4().multiplyMatrices(torsoMatrix, neckMatrix);
var headMatrix = new THREE.Matrix4().set(1,0,0,0, 0,1,0,2.5, 0,0,1,0.5, 0,0,0,1);
var headnecktorsoMatrix = new THREE.Matrix4().multiplyMatrices(necktorsoMatrix, headMatrix);

//initialize matrices for legs here:


// CREATE BODY
var torso = new THREE.Mesh(torsoGeometry, normalMaterial);
torso.setMatrix(torsoMatrix)
scene.add(torso);

var neck = new THREE.Mesh(neckGeometry, normalMaterial);
neck.setMatrix(necktorsoMatrix);
scene.add(neck);

var head = new THREE.Mesh(headGeometry, normalMaterial);
head.setMatrix(headnecktorsoMatrix);
scene.add(head);

//create legs and add them to the scene here:


//APPLY DIFFERENT EFFECTS TO DIFFERNET CHANNELS
var clock = new THREE.Clock(true);
function updateBody() {

  switch(channel)
  {
    //animation
    case 0: 
      {
        var t = clock.getElapsedTime();

        //animate legs here:
      }
      break;

    //add poses here:
    case 1:
      
      break;

    case 2:

      break;

    case 3:

      break;

    case 4:

      break;

    case 5:

      break;

    default:
      break;
  }
}


// LISTEN TO KEYBOARD
var keyboard = new THREEx.KeyboardState();
var channel = 0;
function checkKeyboard() {
  for (var i=0; i<6; i++)
  {
    if (keyboard.pressed(i.toString()))
    {
      channel = i;
      break;
    }
  }
}


// SETUP UPDATE CALL-BACK
function update() {
  checkKeyboard();
  updateBody();

  requestAnimationFrame(update);
  renderer.render(scene, camera);
}

update();